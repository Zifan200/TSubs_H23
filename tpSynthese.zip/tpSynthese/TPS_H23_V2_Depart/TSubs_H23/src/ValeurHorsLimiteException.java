// Exception personnalisée pour une valeur hors limite
//TODO 8
public class ValeurHorsLimiteException extends Exception{
    public ValeurHorsLimiteException(String message) {
        super(message);
    }
}
