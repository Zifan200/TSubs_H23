public class Noeud {
    Noeud suivant;
    Noeud precedent;
    int valeur;

    public Noeud(int valeur) {
        this.valeur = valeur;
    }
}
