package messages;

public interface MessagePrive {
    static final char PREFIX = '@';

    String getDestinataire();
}
