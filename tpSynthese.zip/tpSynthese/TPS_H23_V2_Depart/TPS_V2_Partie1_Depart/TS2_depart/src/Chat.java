// Classe dérivée
// TODO 1.2
