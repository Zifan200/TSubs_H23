// Exception personnalisée pour une valeur hors limite
//TODO 8