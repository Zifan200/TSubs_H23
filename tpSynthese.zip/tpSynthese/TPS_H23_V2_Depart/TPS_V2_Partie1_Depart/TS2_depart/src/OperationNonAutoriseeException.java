// Exception personnalisée pour une opération non autorisée
//TODO 9
